package com.springframwork.learnApp;

import com.springframwork.learnApp.Game.GameRunner;

import com.springframwork.learnApp.Game.MarioGame;

public class AppGamingBasicJavaTightcoupling {
	public static void main(String[] args) {
		var  MarioGame=new MarioGame();
		var GameRunner=new GameRunner(MarioGame);
		GameRunner.run();
	
		
	}

}
 