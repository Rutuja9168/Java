package com.springframwork.learnApp.Game;

public class MarioGame {
	public void left() {
		System.out.println("forward move");
	}
	public void right() {
		System.out.println("back side move");
		
	}
   public void top() {
	   System.out.println("Jump");
	   
   }
   public void buttom() {
	   System.out.println("speed");
	   
   }
}
