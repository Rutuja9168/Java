package com.springframwork.learnApp.Game;

public class GameRunner {
	MarioGame marioGame;
 public GameRunner(MarioGame marioGame) {
	 this.marioGame=marioGame;
	 
 }
 public void run() {
	 System.out.println("game Running");
	 this.marioGame.buttom();
	 this.marioGame.left();
	 this.marioGame.right();
	 this.marioGame.top();
 }
}
